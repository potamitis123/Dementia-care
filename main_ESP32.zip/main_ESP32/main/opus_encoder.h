#ifndef OPUS_ENCODER_H
#define OPUS_ENCODER_H
#include <stdio.h>
#include <string.h>

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "esp_audio_enc.h"
#include <global_heads.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define OPUS_SAMPLE_RATE       16000
#define OPUS_CHANNELS          1
#define OPUS_BITS_PER_SAMPLE   16
//#define OPUS_DURATION_SEC      10
#define OPUS_FRAME_SIZE        320     // 20ms at 16kHz
//#define OPUS_MAX_PACKET_SIZE   1024*4    // Maximum size of an Opus packet

#define PCM_BUFFER_SIZE        (SAMPLE_RATE * RECORD_TIME * (OPUS_BITS_PER_SAMPLE/8) * OPUS_CHANNELS)
//#define OPUS_BUFFER_SIZE       ((PCM_BUFFER_SIZE / OPUS_FRAME_SIZE + 1) * OPUS_MAX_PACKET_SIZE)
#define OPUS_BUFFER_SIZE       (PCM_BUFFER_SIZE/2)

#define OPUS_ENCODED_START_BIT     BIT0
#define OPUS_ENCODED_END_BIT       BIT1
typedef struct {
    esp_audio_enc_handle_t encoder;
    uint8_t *encoded_buffer;
    size_t encoded_size;
    bool initialized;
} opus_encoder_t;



// Στο opus_encoder.h
typedef struct {
    opus_encoder_t *encoder_handle;
    const int16_t *pcm_buffer;
    size_t pcm_size;
    size_t *encoded_size;
    EventGroupHandle_t encode_event_group;
    esp_err_t status;
} opus_encode_params_t;

/**
 * @brief Αρχικοποιεί τον OPUS encoder
 * 
 * @param encoder_handle Pointer στο handle του encoder
 * @return esp_err_t ESP_OK σε περίπτωση επιτυχίας
 */
esp_err_t opus_init_encoder(opus_encoder_t *encoder_handle);

void opus_encode_task(void *pvParameters) ;


/**
 * @brief Κωδικοποιεί PCM δεδομένα σε OPUS format
 * 
 * @param encoder_handle Handle του encoder
 * @param pcm_buffer Buffer με τα PCM δεδομένα
 * @param pcm_size Μέγεθος των PCM δεδομένων σε bytes
 * @param encoded_size Pointer όπου θα αποθηκευτεί το μέγεθος των κωδικοποιημένων δεδομένων
 * @return uint8_t* Pointer στα κωδικοποιημένα δεδομένα ή NULL σε περίπτωση σφάλματος
 */
// uint8_t* opus_encode_buffer(opus_encoder_t *encoder_handle, 
//                           const int16_t *pcm_buffer, 
//                           size_t pcm_size, 
//                           size_t *encoded_size);

/**
 * @brief Απελευθερώνει τους πόρους του encoder
 * 
 * @param encoder_handle Handle του encoder
 * @return esp_err_t ESP_OK σε περίπτωση επιτυχίας
 */
esp_err_t opus_encoder_cleanup(opus_encoder_t *encoder_handle);

#endif // OPUS_ENCODER_H
