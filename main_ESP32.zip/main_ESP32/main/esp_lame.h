// esp_lame.h
#ifndef ESP_LAME_H
#define ESP_LAME_H
#include <global_heads.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdint.h>
#include "esp_err.h"
#include "lame.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef struct {
    int sample_rate;
    int channels;
    int bitrate;
    int quality;  // 0 = best, 9 = worst
} esp_lame_config_t;



typedef struct esp_lame_encoder_t {
    lame_global_flags *gfp;
} esp_lame_encoder_t;


typedef struct {
    esp_lame_encoder_t encoder_handle;
    const int16_t *pcm_buffer;
    size_t pcm_size;
    uint8_t *encoded_buffer;
    size_t *encoded_size;
    EventGroupHandle_t encode_event_group;
    esp_err_t status;
} lame_encode_params_t;


esp_err_t esp_lame_init(esp_lame_config_t *config, esp_lame_encoder_t *handle);
//esp_err_t esp_lame_encode(esp_lame_handle_t handle, const int16_t *pcm, size_t samples, uint8_t *mp3_buffer, size_t *mp3_size);
void esp_lame_cleanup(esp_lame_encoder_t *handle);
void lame_encode_task(void *pvParameters) ;


#ifdef __cplusplus
}
#endif

#endif // ESP_LAME_H