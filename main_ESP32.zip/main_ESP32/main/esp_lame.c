// esp_lame.c
#include "esp_lame.h"

#include "esp_system.h"
#include <esp_types.h>
#include <stdio.h>
#include "rom/ets_sys.h"
#include "esp_heap_caps.h"
#include <stdlib.h>
#include <string.h>
#include "esp_log.h"
#include "esp_system.h"


static const char *TAG = "ESP_LAME";

esp_err_t esp_lame_init(esp_lame_config_t *config, esp_lame_encoder_t *handle) {
    if (!handle) {
        return ESP_ERR_NO_MEM;
    }

    handle->gfp = lame_init();
    if (!handle->gfp) {
        //free(handle);
        return ESP_FAIL;
    }
    
    lame_set_VBR(handle->gfp, vbr_default);
    lame_set_in_samplerate(handle->gfp, config->sample_rate);
    lame_set_num_channels(handle->gfp, config->channels);
    lame_set_quality(handle->gfp, config->quality);
    lame_set_mode(handle->gfp, MONO); 

    if (lame_init_params(handle->gfp) < 0) {
        lame_close(handle->gfp);
        //free(enc);
        return ESP_FAIL;
    }

  
    return ESP_OK;
}

void lame_encode_task(void *pvParameters) {
    lame_encode_params_t *params = (lame_encode_params_t *)pvParameters;
    
    int framesize = lame_get_framesize(params->encoder_handle.gfp);
    ESP_LOGI(TAG,"Framesize = %d\n", framesize);
    int num_samples_encoded=0;
   
    int frames=0;
    int nsamples=1152;
    size_t total_encoded = 0;



    ESP_LOGI(TAG, "Free heap: %ld", esp_get_free_heap_size());

    size_t total_samples = params->pcm_size / sizeof(int16_t);
    int16_t *current_pcm = (int16_t *)params->pcm_buffer;

   

    //num_samples_encoded = lame_encode_buffer_interleaved(params->encoder_handle.gfp, params->pcm_buffer, num_samples, params->encoded_buffer, params->encoded_size);
    while (total_samples >= nsamples) {
        // Κωδικοποίηση ενός frame
        num_samples_encoded = lame_encode_buffer(
            params->encoder_handle.gfp,
            current_pcm,           // Αριστερό κανάλι (mono)
            NULL,                  // Δεξί κανάλι (NULL για mono)
            nsamples,             // Samples ανά frame
            params->encoded_buffer + total_encoded,  // Τρέχουσα θέση στο mp3 buffer
            *params->encoded_size - total_encoded  // Διαθέσιμος χώρος
        );
        if(num_samples_encoded == 0){
            ESP_LOGE(TAG, "Error encoding frame: %d", num_samples_encoded);
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }else if(num_samples_encoded == -1){
            ESP_LOGE(TAG, "Error mp3buffer too small: ");
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }else if(num_samples_encoded == -2){
            ESP_LOGE(TAG, "Error malloc problem: ");
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }else if(num_samples_encoded == -3){
            ESP_LOGE(TAG, "Error lame_init_params not called: ");
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }else if(num_samples_encoded == -4){
            ESP_LOGE(TAG, "Error psycho acoustic problems");
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }else if (num_samples_encoded < 0) {
            ESP_LOGE(TAG, "Error encoding frame: %d", num_samples_encoded);
            lame_close(params->encoder_handle.gfp);
            params->encoder_handle.gfp = NULL;
            params->status = ESP_FAIL;
            return;
        }

        total_encoded += num_samples_encoded;
        current_pcm += nsamples;
        total_samples -= nsamples;
        frames++;
        vTaskDelay(pdMS_TO_TICKS(10));

    }

    // Flush τυχόν εναπομείναντα δεδομένα
    num_samples_encoded = lame_encode_flush(
        params->encoder_handle.gfp, 
        params->encoded_buffer + total_encoded, 
        *params->encoded_size - total_encoded
    );

    if (num_samples_encoded > 0) {
        total_encoded += num_samples_encoded;
    }

    // Ενημέρωση του μεγέθους των κωδικοποιημένων δεδομένων
    *params->encoded_size = total_encoded;

    ESP_LOGI(TAG, "Encoded %d frames, total %d bytes", frames, total_encoded);
    
    //lame_close(params->encoder_handle.gfp);

    if ( *(params->encoded_size) > 0) {
        ESP_LOGI(TAG, " total %d num_samples_encoded %d", *params->encoded_size,num_samples_encoded);
        params->status = ESP_OK;
    }else{
        lame_close(params->encoder_handle.gfp);
        params->encoder_handle.gfp = NULL;
        params->status = ESP_FAIL;
    }

    return; 
}

void esp_lame_cleanup(esp_lame_encoder_t *handle) {
    if (handle) {
        if (handle->gfp) {
            lame_close(handle->gfp);
        }
        //free(handle);
    }
}