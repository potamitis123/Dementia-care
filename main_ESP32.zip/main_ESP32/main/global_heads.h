#ifndef GLOBAL_HEADS_H
#define GLOBAL_HEADS_H

//#define LOG_LOCAL_LEVEL ESP_LOG_DEBUG

//#define SAMPLE_RATE     16000
#define SAMPLE_BITS     32 
//#define RECORD_TIME     4   
//#define BUFFER_SIZE     (SAMPLE_RATE * RECORD_TIME * (SAMPLE_BITS/8))

#define MEM_STATISTICS 1
#define MP3 1
#define OPUS 0
#define RAW 2
#define ENCODER_TYPE MP3
#define MQTT_SEND 1
#define MQTT_TLS 1

//********************************************************* */
#define DEVICE_NAME esp32s3-1


#define FIRSTBOOT 0

# define USB 0
# define I2S 1
#define MIC_TYPE I2S  //USB or I2S
//********************************************************* */

#if DEVICE_NAME == esp32s3-1
    #define MQTT_CLIENT_ID  "esp32s3-1"
    #define MQTT_USERNAME   "esp32s3-1"
    #define MQTT_PASSWORD   "ast-esp32s3-1"
#elif DEVICE_NAME == esp32s3-2
    #define MQTT_CLIENT_ID  "esp32s3-2"
    #define MQTT_USERNAME   "esp32s3-2"
    #define MQTT_PASSWORD   "ast-esp32s3-2"
#elif DEVICE_NAME == esp32s3-3
    #define MQTT_CLIENT_ID  "esp32s3-3"
    #define MQTT_USERNAME   "esp32s3-3"
    #define MQTT_PASSWORD   "ast-esp32s3-3"
#elif DEVICE_NAME == esp32s3-4
    #define MQTT_CLIENT_ID  "esp32s3-4"
    #define MQTT_USERNAME   "esp32s3-4"
    #define MQTT_PASSWORD   "ast-esp32s3-4"
#endif

#endif