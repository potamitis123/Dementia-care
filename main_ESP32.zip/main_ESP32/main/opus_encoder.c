#include "opus_encoder.h"
#include "esp_log.h"
#include "esp_audio_enc.h"
#include "esp_opus_enc.h"
#include "esp_heap_caps.h"


static const char *TAG = "OPUS_ENCODER";

esp_err_t opus_init_encoder(opus_encoder_t *encoder_handle) {
    if (encoder_handle == NULL) {
        ESP_LOGE(TAG, "Invalid encoder handle");
        return ESP_ERR_INVALID_ARG;
    }

    // Αρχικοποίηση της δομής
    encoder_handle->initialized = false;
    encoder_handle->encoded_buffer = NULL;
    encoder_handle->encoded_size = 0;

    

    // Διαμόρφωση του OPUS encoder
    esp_opus_enc_config_t opus_cfg = {
        .sample_rate = OPUS_SAMPLE_RATE,
        .channel = OPUS_CHANNELS,
        .bits_per_sample = OPUS_BITS_PER_SAMPLE,
        .frame_duration = ESP_OPUS_ENC_FRAME_DURATION_20_MS,
        .application_mode = ESP_OPUS_ENC_APPLICATION_AUDIO ,//,ESP_OPUS_ENC_APPLICATION_LOWDELAY
        .complexity = 0,  // Μέγιστη ποιότητα 10
        .bitrate = 128000,  // 128 kbps
    };

    // Δημιουργία του encoder
    esp_err_t ret = esp_opus_enc_open(&opus_cfg, sizeof(esp_opus_enc_config_t), &encoder_handle->encoder);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to open OPUS encoder: %d", ret);
        return ret;
    }

    // Δέσμευση buffer για τα κωδικοποιημένα δεδομένα
    encoder_handle->encoded_buffer = heap_caps_malloc(OPUS_BUFFER_SIZE,MALLOC_CAP_SPIRAM );//MALLOC_CAP_8BIT
    if (encoder_handle->encoded_buffer == NULL) {
        ESP_LOGE(TAG, "Failed to allocate encoded buffer");
        esp_opus_enc_close(encoder_handle->encoder);
        return ESP_ERR_NO_MEM;
    }
    
    
    encoder_handle->initialized = true;
    ESP_LOGI(TAG, "OPUS encoder initialized successfully Opus Buffer %d",OPUS_BUFFER_SIZE);
    return ESP_OK;
}

void opus_encode_task(void *pvParameters) {
    opus_encode_params_t *params = (opus_encode_params_t *)pvParameters;
    if (!params) {
        ESP_LOGE(TAG, "params is NULL");
    }
    if (!params->encoder_handle) {
        ESP_LOGE(TAG, "encoder_handle is NULL");
    }
    if (!params->encoder_handle->encoder) {
        ESP_LOGE(TAG, "encoder is NULL");
    }
    

    size_t total_encoded_size = 0;
    size_t remaining_bytes = params->pcm_size;
    uint8_t *current_output = params->encoder_handle->encoded_buffer;
    size_t frame_count = 0;
    
    int input_frame_size= OPUS_FRAME_SIZE * sizeof(int16_t);
    int output_frame_size=0;
    ESP_LOGI(TAG, "Starting encoding of %d bytes PCM data", params->pcm_size);

    esp_opus_enc_get_frame_size(params->encoder_handle->encoder, &input_frame_size, &output_frame_size); //esp_opus_enc_get_frame_size
    ESP_LOGI(TAG, "Input frame size %d bytes, Output frame size  %d bytes ", input_frame_size, output_frame_size);
     
    while (remaining_bytes >= input_frame_size) {
        ESP_LOGI(TAG, "Encoding 0");
        esp_audio_enc_in_frame_t in_frame = {
            .buffer = (uint8_t*)(params->pcm_buffer + (frame_count * input_frame_size)),
            .len = input_frame_size
        };

        esp_audio_enc_out_frame_t out_frame = {
            .buffer = current_output,
            .len = output_frame_size
        };
        if (!in_frame.buffer) {
            ESP_LOGE(TAG, "input buffer is NULL");
        }
        if (!out_frame.buffer) {
            ESP_LOGE(TAG, "output buffer is NULL");
        }
        
        ESP_LOGI(TAG, "Encoding frame %d, offset: %d", frame_count, 
                 frame_count * input_frame_size);

        esp_err_t ret = esp_opus_enc_process(params->encoder_handle->encoder, &in_frame, &out_frame);
        
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to encode OPUS frame: %d", ret);
            params->status = ret;
            goto exit;
        }
        current_output += out_frame.encoded_bytes;
        total_encoded_size += out_frame.encoded_bytes;
        remaining_bytes -= input_frame_size;
        frame_count++;
    }
    ESP_LOGI(TAG, "Encoding total_encoded_size: %d remaining_bytes: %d", total_encoded_size, remaining_bytes);
    params->encoded_size = &total_encoded_size;
    params->status = ESP_OK;

exit:
    xEventGroupSetBits(params->encode_event_group, OPUS_ENCODED_END_BIT);
    vTaskDelete(NULL);
}


// Στο opus_encoder.c
// uint8_t* opus_encode_buffer(opus_encoder_t *encoder_handle, 
//                           const int16_t *pcm_buffer, 
//                           size_t pcm_size, 
//                           size_t *encoded_size) 
// {
//     if (!encoder_handle || !encoder_handle->initialized || !pcm_buffer || !encoded_size) {
//         ESP_LOGE(TAG, "Invalid parameters for encoding");
//         return NULL;
//     }

//     EventGroupHandle_t encode_event_group = xEventGroupCreate();
//     xEventGroupSetBits(encode_event_group, OPUS_ENCODED_START_BIT);
    

//     opus_encode_params_t params = {
//         .encoder_handle = encoder_handle,
//         .pcm_buffer = pcm_buffer,
//         .pcm_size = pcm_size,
//         .encoded_size = encoded_size,
//         .encode_event_group = encode_event_group,
//         .status = ESP_OK
//     };

//     xTaskCreate(opus_encode_task, "opus_encode", 8192*3, &params, 5, NULL);

//      EventBits_t bits = xEventGroupWaitBits(params.encode_event_group,
//             OPUS_ENCODED_END_BIT,
//             pdFALSE,
//             pdFALSE,
//             portMAX_DELAY);

//     if (params.status != ESP_OK) {
//         encoded_size = 0;
//         return NULL;
//     }
//     encoded_size = params.encoded_size;
//     return params.encoder_handle->encoded_buffer;
// }

esp_err_t opus_encoder_cleanup(opus_encoder_t *encoder_handle) {
    if (!encoder_handle) {
        ESP_LOGE(TAG, "Invalid encoder handle for cleanup");
        return ESP_ERR_INVALID_ARG;
    }

    if (encoder_handle->initialized) {
        if (encoder_handle->encoded_buffer) {
            heap_caps_free(encoder_handle->encoded_buffer);
            encoder_handle->encoded_buffer = NULL;
        }
        if (encoder_handle->encoder) {
            esp_opus_enc_close(encoder_handle->encoder);
            //if (ret != ESP_OK) {
            //    ESP_LOGE(TAG, "Error closing OPUS encoder: %d", ret);
            //    return ret;
           // }
            encoder_handle->encoder = NULL;
        }
        encoder_handle->initialized = false;
        ESP_LOGI(TAG, "OPUS encoder cleaned up successfully");
    }

    return ESP_OK;
}