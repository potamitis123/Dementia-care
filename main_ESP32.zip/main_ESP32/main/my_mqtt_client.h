#ifndef MQTT_CLIENT_H
#define MQTT_CLIENT_H

#include <stdbool.h>
#include "esp_system.h"
#include "mqtt_client.h"
#include "global_heads.h"
#include "confing_file.h"

//#define MQTT_BROKER     "BROKER"
//#define MQTT_PORT       1883
//#define MQTT_TOPIC      "audio/recordings/esp32s3-2"
//#define MQTT_CLIENT_ID  "esp32s3-2"
//#define MQTT_USERNAME   "esp32s3-2"
//#define MQTT_PASSWORD   "ast-esp32s3-2"
#define CHUNK_SIZE      6144

#define MQTT_NOT_CONNECTED_BIT BIT0
#define MQTT_CONNECTED_BIT BIT1

#define MQTT_TOPIC      "audio/recordings/"


typedef struct {
    const uint8_t *mqtt_buffer;
    size_t mqtt_buffer_size;
    char data_format[10];
    esp_err_t status;
    Rec_config_file_t *rec_config_file;
} task_params_t_publish_audio_chunks;

bool mqtt_init_client(Rec_config_file_t *rec_config_file);
void publish_audio_chunks(void* pvpublish_audio_chunks);

#endif
